package application;

import java.io.IOException;
import com.google.gson.Gson;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

public class SampleController {

    @FXML
    private AnchorPane anchor_pane;

    @FXML
    private BorderPane borderpane;

    @FXML
    private Button btnSearch;

    @FXML
    private Label errMsgLabel;

    @FXML
    private HBox h_box;

    @FXML
    private Label label1;

    @FXML
    private Label mTitle;

    @FXML
    private Label mYear;

    @FXML
    private ImageView posterImageView;

    @FXML
    private TextField searchTextField;

    @FXML
    public void getSearchResults() {
        OMDBAPIService omdbService = new OMDBAPIService();
        try {
            String searchTerm = searchTextField.getText();
            String searchParam = searchTerm.toString();
            String jsonInput = omdbService.searchMovies(searchParam);

            Gson gson = new Gson();
            SearchResult searchResult = gson.fromJson(jsonInput, SearchResult.class);

            // When no movies are found, handle the case
            if (searchResult == null || searchResult.getSearch() == null || searchResult.getSearch().isEmpty()) {
                errMsgLabel.setText("No movies matched your search");
                errMsgLabel.setVisible(true);
                mTitle.setText("");
                mYear.setText("");
                posterImageView.setImage(null);
            } else {
                errMsgLabel.setVisible(false);
                int i = 0;
                for (Movie movie : searchResult.getSearch()) {
                    if (i == 0) {
                        mTitle.setText(movie.getTitle());
                        mYear.setText(movie.getYear());
                        String imageUrl = movie.getPoster();
                        this.setPosteImage(imageUrl);
                        i++;
                        break;
                    }
                }
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            errMsgLabel.setText("Error fetching data");
            errMsgLabel.setVisible(true);
        }
    }

    public void setPosteImage(String imageUrl) {
        if (imageUrl != null && !imageUrl.isEmpty()) {
            Image image = new Image(imageUrl);
            posterImageView.setImage(image);
        } else {
            posterImageView.setImage(null);
        }
    }
}